import { Component, OnInit } from '@angular/core';
import { VisitService } from '../../services/visits.service';
import { Visit } from '../../services/visits.service';

@Component({
  selector: 'app-visits',
  standalone:true,
  templateUrl: './visitdetails.component.html',
  styleUrls: ['./visitdetails.component.scss']
})
export class VisitsComponent implements OnInit {
  visits: Visit[] = [];  // 👈 Type is known

  constructor(private visitService: VisitService) {}

  ngOnInit() {
    this.loadVisits();
  }

  loadVisits() {
    this.visitService.getVisits().subscribe({
      next: (data) => (this.visits = data),
      error: (err) => console.error('Error loading visits:', err)
    });
  }

  deleteVisit(id: number) {
    this.visitService.deleteVisit(id).subscribe({
      next: () => this.loadVisits(),
      error: (err) => console.error('Error deleting visit:', err)
    });
  }

  addVisit() {
    const newVisit: Visit = {
      visitId: 0,              // backend generates the ID
      patientId: 1,            // default patientId
      doctorId: 1,             // default doctorId
      visitTypeId: 1,          // default visit type
      duration: 30,            // default duration in minutes
      visitDate: new Date(),   // current date
      doctorNotes: 'N/A'       // default notes
    };

    this.visitService.addVisit(newVisit).subscribe({
      next: () => this.loadVisits(),
      error: (err) => console.error('Error adding visit:', err)
    });
  }
}
