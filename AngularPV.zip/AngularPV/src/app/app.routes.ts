import { Routes } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
import { RegisterComponent } from './login/register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DoctorsComponent } from './doctors/doctor/doctor.component';
import { PatientsComponent } from './patients/patient/patient.component';
import { VisitsComponent } from './Visits/visitdetails/visitdetails.component';



export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'patients', component: PatientsComponent },
  { path: 'doctors', component: DoctorsComponent },
  {path: 'visits' , component:VisitsComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' }
];
