import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface representing a Visit object
export interface Visit {
  visitId: number;
  patientId: number;
  doctorId: number;
  visitTypeId: number;
  duration: number;       // Duration in minutes (or as per your backend)
  visitDate: Date;      // ISO string date format
  doctorNotes: string;
}

@Injectable({
  providedIn: 'root'
})
export class VisitService {
  // Base URL for Visit API
  private baseUrl = 'https://localhost:5001/api/Visits';

  constructor(private http: HttpClient) {}

  /** Get all visits */
  getVisits(): Observable<Visit[]> {
    return this.http.get<Visit[]>(this.baseUrl);
  }

  /** Get a single visit by ID */
  getVisitById(id: number): Observable<Visit> {
    return this.http.get<Visit>(`${this.baseUrl}/${id}`);
  }

  /** Add a new visit */
  addVisit(visit: Visit): Observable<Visit> {
    return this.http.post<Visit>(this.baseUrl, visit);
  }

  /** Update an existing visit */
  updateVisit(id: number, visit: Visit): Observable<Visit> {
    return this.http.put<Visit>(`${this.baseUrl}/${id}`, visit);
  }

  /** Delete a visit by ID */
  deleteVisit(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
