import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Visit {
  visitId: number;
  patientId: number;
  doctorId: number;
  visitTypeId: number;
  duration: number;
  visitDate: Date;
  doctorNotes: string;
}

@Injectable({ providedIn: 'root' })
export class VisitsService {
  private apiUrl = 'https://localhost:5001/api/visits';

  constructor(private http: HttpClient) {}

  getVisits(): Observable<Visit[]> {
    return this.http.get<Visit[]>(this.apiUrl);
  }

  addVisit(visit: Visit): Observable<Visit> {
    return this.http.post<Visit>(this.apiUrl, visit);
  }

  deleteVisit(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
