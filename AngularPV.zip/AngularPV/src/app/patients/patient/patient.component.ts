import { Component, OnInit } from '@angular/core';
import { PatientService, Patient } from '../../services/patient.service';

@Component({
  selector: 'app-patients',
  templateUrl: './patient.component.html'
})
export class PatientsComponent implements OnInit {
  patients: Patient[] = [];
  loading = false;
  error: string | null = null;

  constructor(private patientService: PatientService) {}

  ngOnInit(): void {
    this.loadPatients();
  }

  loadPatients(): void {
    this.loading = true;
    this.patientService.getPatients().subscribe({
      next: (data: Patient[]) => {
        this.patients = data;
        this.loading = false;
      },
      error: (err: any) => {
        console.error('Error loading patients:', err);
        this.error = 'Failed to load patients from database';
        this.loading = false;
      }
    });
  }

  deletePatient(id: number): void {
    this.patientService.deletePatient(id).subscribe({
      next: () => {
        this.patients = this.patients.filter(p => p.patientId !== id);
      },
      error: (err: any) => {
        console.error('Error deleting patient:', err);
        this.error = 'Failed to delete patient';
      }
    });
  }

  addPatient(): void {
    const newPatient: Patient = {
      patientId: 0, // backend will generate ID
      patientName: 'New Patient',
      patientPhone: '000-000-0000'
    };

    this.patientService.addPatient(newPatient).subscribe({
      next: (created: Patient) => {
        this.patients.push(created);
      },
      error: (err: any) => {
        console.error('Error adding patient:', err);
        this.error = 'Failed to add patient';
      }
    });
  }
}
