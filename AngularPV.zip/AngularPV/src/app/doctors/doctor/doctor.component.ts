import { Component, OnInit } from '@angular/core';
import { DoctorsService } from '../../services/doctor.service';
import { Doctor } from '../../services/doctor.service';


@Component({
  selector: 'app-doctors',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.scss']
})
export class DoctorsComponent implements OnInit {
  doctors: Doctor[] = [];   // 👈 Now Angular knows this type

  constructor(private doctorsService: DoctorsService) {}

  ngOnInit() {
    this.loadDoctors();
  }

  loadDoctors() {
    this.doctorsService.getDoctors().subscribe({
      next: (data) => (this.doctors = data),
      error: (err) => console.error(err)
    });
  }

  deleteDoctor(id: number) {
    this.doctorsService.deleteDoctor(id).subscribe({
      next: () => this.loadDoctors()
    });
  }

  addDoctor() {
    const newDoctor: Doctor = { doctorId: 0, doctorName: 'New Doctor', doctorSpecialty: 'General' };
    this.doctorsService.addDoctor(newDoctor).subscribe({
      next: () => this.loadDoctors()
    });
  }
}
