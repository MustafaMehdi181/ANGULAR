import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService, LoginModel } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone:true,
  imports: [FormsModule , RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  model: LoginModel = { email: '', passwords: '' };
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.authService.login(this.model).subscribe(
      (res: string) => {
        console.log('Login success:', res);
        this.router.navigate(['/dashboard']);  // 👈 redirect
      },
      (err) => {
        console.error('Login failed:', err);
        this.errorMessage = 'Invalid login';
      }
    );
  }
}
