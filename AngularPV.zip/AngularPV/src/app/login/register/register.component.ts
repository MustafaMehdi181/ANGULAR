import { Component } from '@angular/core';
import { AuthService, RegisterModel } from '../../services/auth.service'; // 👈 correct import path
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true, // if standalone
  imports: [FormsModule,RouterLink],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  model: RegisterModel = { email: '', passwords: '' };

  constructor(private authService: AuthService) {}

  onSubmit() {
    this.authService.register(this.model).subscribe({
      next: (res: any) => {
        console.log('Registration success:', res);
      },
      error: (err: any) => {
        console.error('Registration failed:', err);
      }
    });
  }
}
