import { Injectable } from '@angular/core';


interface Contact {
  id: number;
  name: string;
  phone: string;
  email: string;
  gender: 'Male' | 'Female';
  address: string;
  groups: string[];
}

@Injectable({
  providedIn: 'root'
})


export class ContactService {

   contacts: Contact[] = [];
  

  generateMockContacts() {
    const firstName = ['Ali', 'Rashid', 'Sharjeel', 'Awais', 'Rahim', 'Zohaib', 'John', 'Hamid', 'Kumail', 'Farkhanda'];
    const lastName = ['Khokhar', 'Cheema', 'Hafeez', 'Jutt', 'Rana', 'Farzad', 'Paracha', 'Noman', 'Zakria', 'Tufail'];
    const streets = ['St#1 JT', 'Walton Rd', 'Mall Rd', 'Fortress Rd', 'Jail Rd'];
    const cities = ['Lahore', 'Karachi', 'Sargodha', 'Pindi', 'Mianwali'];
    const groupsList = ['Favourites', 'Family', 'Friends', 'Classmates'];
    const genders: ('Male' | 'Female')[] = ['Male', 'Female'];

    for (let i = 1; i <= 50; i++) {
      const name = `${this.randomItem(firstName)} ${this.randomItem(lastName)}`;
      const phone = `+1-202-${this.pad(i)}-${this.pad(Math.floor(Math.random() * 10000))}`;
      const email = `${name.toLowerCase().replace(' ', '.')}@example.com`;
      const gender = this.randomItem(genders);
      const address = `${Math.floor(Math.random() * 999)} ${this.randomItem(streets)}, ${this.randomItem(cities)}`;
      const groups = this.shuffle(groupsList).slice(0, Math.floor(Math.random() * 3) + 1);

      this.contacts.push({ id: i, name, phone, email, gender, address, groups });
    }
  }

  randomItem<T>(arr: T[]): T {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  pad(num: number): string {
    return num.toString().padStart(4, '0');
  }

  shuffle<T>(array: T[]): T[] {
    const a = array.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }


  constructor() { }
}
