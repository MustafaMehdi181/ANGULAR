import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AbstractControl, ValidationErrors, ValidatorFn, FormArray } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports:[ReactiveFormsModule,CommonModule],
  templateUrl: './addform.component.html',
})
export class AddformComponent {
  contactForm: FormGroup;
  groupList = ['All', 'Favourites', 'Family', 'Friends', 'Classmates'];
  submitted = false;

  constructor(private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      id: ['', [Validators.required, Validators.min(1)]],
      name: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      gender: ['', Validators.required],
      address: ['', Validators.required],
      groups: this.fb.array(this.groupList.map(() => false), this.minSelectedCheckboxes(1))
    });
  }

  get groupsFormArray() {
    return this.contactForm.get('groups') as FormArray;
  }

  minSelectedCheckboxes(min = 1): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const formArray = control as FormArray;
    const totalSelected = formArray.controls
      .map(ctrl => ctrl.value)
      .reduce((prev, next) => next ? prev + 1 : prev, 0);

    return totalSelected >= min ? null : { required: true };
  };
}

  onSubmit() {
    this.submitted = true;
    if (this.contactForm.valid) {
      // Map group booleans to group names
      const selectedGroups = this.contactForm.value.groups
        .map((checked: boolean, i: number) => checked ? this.groupList[i] : null)
        .filter((v: string | null) => v !== null);
      
      const formData = {
        ...this.contactForm.value,
        groups: selectedGroups
      };

      console.log(formData);
    }
  }
}
