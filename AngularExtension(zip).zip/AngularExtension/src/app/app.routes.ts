import { Routes } from '@angular/router';
import { PanelComponent } from './panel/panel.component';
import { AddformComponent } from './addform/addform.component';


export const routes: Routes = [
    //{path:'',redirectTo:'/dashboard',pathMatch:'full'},
    {path:'dashboard',component:PanelComponent,pathMatch:'full'},
    {path: 'AddContact' , component: AddformComponent , pathMatch:'full'}
       
];
