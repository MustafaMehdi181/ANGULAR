import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';  // <-- Import CommonModule for *ngIf, *ngFor

interface Contact {
  id: number;
  name: string;
  phone: string;
  email: string;
  gender: 'Male' | 'Female';
  address: string;
  groups: string[];
}

@Component({
  selector: 'app-root',
  standalone: true,               
  imports: [CommonModule],        
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  filters = ['All', 'Favourites', 'Family', 'Friends', 'Classmates'];
  currentFilter: string = 'All';

  contacts: Contact[] = [];
  filteredContacts: Contact[] = [];
  selectedContact: Contact | null = null;

  constructor() {
    this.generateMockContacts();
    this.applyFilter();
  }

  generateMockContacts() {
    const firstNames = ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank', 'Grace', 'Hank', 'Ivy', 'Jack'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson', 'Taylor', 'Anderson'];
    const streets = ['Maple St', 'Oak Ave', 'Pine Rd', 'Cedar Ln', 'Elm Blvd'];
    const cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'];
    const groupsList = ['Favourites', 'Family', 'Friends', 'Classmates'];
    const genders: ('Male' | 'Female')[] = ['Male', 'Female'];

    for (let i = 1; i <= 50; i++) {
      const name = `${this.randomItem(firstNames)} ${this.randomItem(lastNames)}`;
      const phone = `+1-202-${this.pad(i)}-${this.pad(Math.floor(Math.random() * 10000))}`;
      const email = `${name.toLowerCase().replace(' ', '.')}@example.com`;
      const gender = this.randomItem(genders);
      const address = `${Math.floor(Math.random() * 999)} ${this.randomItem(streets)}, ${this.randomItem(cities)}`;
      const groups = this.shuffle(groupsList).slice(0, Math.floor(Math.random() * 3) + 1);

      this.contacts.push({ id: i, name, phone, email, gender, address, groups });
    }
  }

  randomItem<T>(arr: T[]): T {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  pad(num: number): string {
    return num.toString().padStart(4, '0');
  }

  shuffle<T>(array: T[]): T[] {
    const a = array.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  applyFilter() {
    if (this.currentFilter === 'All') {
      this.filteredContacts = this.contacts;
    } else {
      this.filteredContacts = this.contacts.filter(c => c.groups.includes(this.currentFilter));
    }
    if (this.selectedContact && !this.filteredContacts.some(c => c.id === this.selectedContact!.id)) {
      this.selectedContact = null;
    }
  }

  onFilterClick(filter: string) {
    this.currentFilter = filter;
    this.applyFilter();
  }

  onSelectContact(contact: Contact) {
    this.selectedContact = contact;
  }

  toggleGroup(group: string) {
    if (!this.selectedContact) return;
    const idx = this.selectedContact.groups.indexOf(group);
    if (idx > -1) {
      this.selectedContact.groups.splice(idx, 1);
    } else {
      this.selectedContact.groups.push(group);
    }
    this.contacts = [...this.contacts];  
    this.applyFilter();
  }

  isInGroup(contact: Contact, group: string) {
    return contact.groups.includes(group);
  }
}
